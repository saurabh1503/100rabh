<?php
namespace Efloor\Common\Block;



class Requestquote extends \Magento\Framework\View\Element\Html\Link
{

    /**
     * Construct
     *
     * @param \Magento\Framework\View\Element\Template\Context $context 
     * @param \Efloor\Review\Model\ResourceModel\Post\CollectionFactory $postCollectionFactory,
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context
  
    ) {
        parent::__construct($context);
    }

    /**
     * Get all the review post
     * 
     * @return \Efloor\Review\Model\ResourceModel\Post\Collection
     */
    public function getLabel() {
        return 'Request a Quote';
    }
}
?>