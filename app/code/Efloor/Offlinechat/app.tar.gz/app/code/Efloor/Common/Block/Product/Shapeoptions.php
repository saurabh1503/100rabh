<?php

/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Efloor\Common\Block\Product;

use Magento\Catalog\Api\ProductRepositoryInterface;

class Shapeoptions extends \Magento\Framework\View\Element\Template {
    
     protected $_registry;
	 protected $productRepository; 
	 protected $productCollectionFactory; 
	 //protected $product; 
    /**
     * @param \Magento\Catalog\Block\Product\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param array $data
     */
    public function __construct(
            \Magento\Catalog\Block\Product\Context $context, 
            \Magento\Framework\Registry $registry,
			ProductRepositoryInterface $productRepository,
			\Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $productCollectionFactory, 
            array $data = []
    ) {	
        $this->registry = $registry;
		$this->productRepository = $productRepository;
		$this->productCollectionFactory = $productCollectionFactory;
		$this->product = $this->registry->registry('current_product');
		 // if($_SERVER['REMOTE_ADDR'] == "182.156.245.130")  { 
			// echo "<pre>"; print_r($this->product->getPproducttypeid()); die;
			// }
        parent::__construct($context,$data);
    }
	
	// public function getCurrentProduct()
    // {      
		// $currentProduct = $this->registry->registry('current_product');
        // $productID= $currentProduct->getId();
		// $product = $this->productRepository->getById($productID);
		// return $product;
    // }
   
    public function getTermModeling() {

        return $this->product->getTrimsMoldings();
    }

    public function getManufacturer() {

        return $this->product->getManufacturer();
    }

    public function getProductTypeID() {

        return $this->product->getPproducttypeid();
    }

    public function getProductCollection() {

        return $this->product->getCollection_name();
    }

    public function getStyleName() {

        return $this->product->getStyle_name();
    }

    public function getProductDesigner() {

        return $this->product->getDesigner();
    }

    public function getProductStyle() {

        return $this->product->getStyle();
    }

    public function getProductLocking() {

        return $this->product->getLocking();
    }

    public function getProductVaccumType() {

        return $this->product->getVacuum_type();
    }

    public function getProductSku() {

        return $this->product->getSku();
    }

    public function getProductEcolor() {

        return $this->product->getEcolor();
    }

	public function getShapeSizeOption(){
		 $productTypeId = $this->product->getPproducttypeid();
		 if($productTypeId == 1) {
		 /**** Get Attribute set name ****/
		$manufacturerId = '';
		$manufacturer = 'arearugs_manufacturer';//str_replace('-', '', $manufacturer);
		if(!empty($manufacturer)){
		$manufacturerId = $this->product->getData($manufacturer);
		}
		/**** End Attribute set name ****/
		 $collection = $this->productCollectionFactory->create();
		 $collection->addAttributeToSelect(['entity_id','price','width','length','arearugs_shape']);
		 $color = $this->getProductEcolor();
         $designer = $this->getProductDesigner();
         $collection_name = $this->getProductCollection();
         $style = $this->getProductStyle();
		 $construction = $this->product->getConstruction();
		 $origin = $this->product->getOrigin();
		 $material = $this->product->getMaterial();
		 
		if (!empty($collection_name)) {
          $collection->addAttributeToFilter('collection_name', array('eq' => "$collection_name")); 	
         }       
		if (!empty($manufacturerId)) {
           $collection->addAttributeToFilter($manufacturer, ['eq' => "$manufacturerId"]);
        }
		
		if (!empty($construction)) {
			$collection->addAttributeToFilter('construction', ['eq' => "$construction"]);
		}
		if (!empty($origin)) {
			$collection->addAttributeToFilter('origin', ['eq' => "$origin"]);
		}
		if (!empty($material)) {
			$collection->addAttributeToFilter('material', ['eq' => "$material"]);
		}
		
		if (!empty($style)) {
			$collection->addAttributeToFilter('style', ['eq' => "$style"]);
		}
		
		if (!empty($color)) {
                $collection->addAttributeToFilter('ecolor', ['eq' => "$color"]);
		}
		
		$collection->addAttributeToFilter('status', array('eq' => 1));
		$collection->addAttributeToFilter('pproducttypeid', array('eq' => 1));
		$collection->setOrder('price','ASC');
		
		return $collection;
		
	 }
		return false;
	}
	
	
		public function getAvalibilityContent() {
	
		$content = "";
        $library_key = $this->product->getpavail();
		
		if(!empty($library_key)) {
			if (strpos($library_key, 'library') !== false) {
			$content = $this->getLibraryHtmlContent($library_key);
			
			return $content;
		 }
		 else{
			 $content = $this->product->getpavail();
			 return $content;
		}	
		}
		
	   return false;
	   
    }

	private function getLibraryHtmlContent($libraryKey){
		
		
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance(); // Instance of object manager
        $resource = $objectManager->get('Magento\Framework\App\ResourceConnection');
        $connection = $resource->getConnection();
        $tableName = $resource->getTableName('efloor_libraryindex'); //gives table name with prefix

        $sql = $connection->select()
                ->from($tableName) // to select all fields            
                ->where('library_key = ?', $libraryKey);
		
        $results = $connection->fetchAll($sql);
		$ibrary_content = '';
		foreach($results as $result) {
			$ibrary_content = $result['library_content'];
		}
		
		return $ibrary_content;
	}	


	

}
