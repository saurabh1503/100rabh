<?php

/**
 * Post search results Interface class for review module
 * 
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */


//Define the namespace
namespace Efloor\Review\Api\Data;

use Magento\Framework\Api\SearchResultsInterface;

/**
 * Interface for cms page search results.
 * @api
 */
interface PostSearchResultsInterface extends SearchResultsInterface
{
    /**
     * Get pages list.
     *
     * @return \Efloor\Review\Api\Data\PostInterface[]
     */
    public function getItems();

    /**
     * Set pages list.
     *
     * @param \Efloor\Review\Api\Data\PostInterface[] $items
     * @return $this
     */
    public function setItems(array $items);
}
