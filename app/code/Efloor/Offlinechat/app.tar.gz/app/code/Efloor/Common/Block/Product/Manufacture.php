<?php

/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Efloor\Common\Block\Product;

use Magento\Catalog\Model\ResourceModel\Product\Collection;
use Magento\Framework\View\Element\AbstractBlock;

 
/**
 * Catalog product related items block
 *
 * @SuppressWarnings(PHPMD.LongVariable)
 */
class Manufacture extends \Magento\Framework\View\Element\Template {

    protected $_categoryFactory;
    protected $attributeSet;
    
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,        
        \Magento\Catalog\Model\CategoryFactory $categoryFactory,
		\Magento\Eav\Api\AttributeSetRepositoryInterface $attributeSet,
        array $data = []
    )
    {    
        $this->_categoryFactory = $categoryFactory;
		$this->attributeSet = $attributeSet;
        parent::__construct($context, $data);
    }
    
    public function getCategory($categoryId) 
    {
        $category = $this->_categoryFactory->create();
        $category->load($categoryId);
        return $category;
    }
   
	
    public function getCategoryProducts($categoryId,$manufacturer,$manufacturerId, $style_vivero = null) 
    {
        $products = $this->getCategory($categoryId)->getProductCollection();
        $products->addAttributeToSelect(['styles_name','style_name','image']);
		$products->addAttributeToFilter($manufacturer, $manufacturerId);
		if(!empty($style_vivero)) {
			$products->addAttributeToFilter('style_name',array('like' => '% '.$style_vivero.' %') );
		}
		$products->addAttributeToFilter('status',\Magento\Catalog\Model\Product\Attribute\Source\Status::STATUS_ENABLED);
		$products->addAttributeToFilter('visibility', \Magento\Catalog\Model\Product\Visibility::VISIBILITY_BOTH);
		
		//$products->distinct(true);
        return $products;
    }
	
 	
	public function getAttributeSetName($product) {

    $attributeSetRepository = $this->attributeSet->get($product->getAttributeSetId());
    return $attributeSetRepository->getAttributeSetName();
}
	 
	 
	
}
