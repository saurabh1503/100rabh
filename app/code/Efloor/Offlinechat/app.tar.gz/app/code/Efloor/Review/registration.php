<?php
	\Magento\Framework\Component\ComponentRegistrar::register(
    	\Magento\Framework\Component\ComponentRegistrar::MODULE,
    		'Efloor_Review',
    __DIR__
	);
?>