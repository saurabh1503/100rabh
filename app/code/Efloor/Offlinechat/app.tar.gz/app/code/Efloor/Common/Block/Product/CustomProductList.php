<?php

/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Efloor\Common\Block\Product;

use Magento\Catalog\Model\ResourceModel\Product\Collection;
use Magento\Framework\View\Element\AbstractBlock;

 
/**
 * Catalog product related items block
 *
 * @SuppressWarnings(PHPMD.LongVariable)
 */
class CustomProductList extends \Magento\Framework\View\Element\Template {

    protected $_categoryFactory;
    protected $attributeSet;
    protected $productCollection;
    protected $storeManager;
	
	
    
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,        
        \Magento\Catalog\Model\CategoryFactory $categoryFactory,
		\Magento\Eav\Api\AttributeSetRepositoryInterface $attributeSet,
		\Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $productCollection,
		\Magento\Store\Model\StoreManagerInterface $storeManager,
        array $data = []
    )
    {    
        $this->_categoryFactory = $categoryFactory;
		$this->attributeSet = $attributeSet;
		$this->_productCollection = $productCollection;
		$this->_storeManager = $storeManager;
		
        parent::__construct($context, $data);
    }
    
    public function getCategory($categoryId) 
    {	$categoryId = $this->getRequest()->getParam('categoryId');
        $category = $this->_categoryFactory->create();
        $category->load($categoryId);
        return $category;
    }
   
	
    public function getCategoryProducts() 
    {	
		 $categoryId = $this->getRequest()->getParam('categoryId');
		 $styleName = $this->getRequest()->getParam('styleName');
		 $manufacturerId = $this->getRequest()->getParam('manufacturerId');
		 $manufacturer = $this->getRequest()->getParam('manufacturer');
		
        $products = $this->getCategory($categoryId)->getProductCollection();
        $products->addAttributeToSelect('*');
		$products->addAttributeToFilter($manufacturer, $manufacturerId);
		$products->addAttributeToFilter('style_name', $styleName);

        return $products;
    }
	
 	

	public function getDaltileSections() 
    {
		$category  =  $this->_categoryFactory->create()->load(788);
		$collection = $this->_productCollection->create()
						->addCategoryFilter($category)
						->addAttributeToSelect(['section_name', 'styles_name','glasstile_manufacturer'])
						->addAttributeToFilter('glasstile_manufacturer', array('eq' => 839))
						->addAttributeToFilter('visibility', \Magento\Catalog\Model\Product\Visibility::VISIBILITY_BOTH)
						->addAttributeToFilter('status',\Magento\Catalog\Model\Product\Attribute\Source\Status::STATUS_ENABLED)
						->distinct(true)
						->load();

		return $collection;						
		
	}
	
	public function getStores() 
    {	
		$store = $this->_storeManager->getStore();
		
        return $store;
    }	
	
}

