<?php
/**
 * Index contoller class to edit the customer reviewin adminhtml
 * 
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Efloor\Review\Controller\Adminhtml\Post;

use Magento\Backend\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;


/**
 * Index Controller class 
 */
class Index extends \Magento\Backend\App\Action
{

    /**
     * @var PageFactory
     */
    protected $resultPageFactory;

    /**
     * @param Context $context
     * @param PageFactory $resultPageFactory
     */
    public function __construct(
        Context $context,
        PageFactory $resultPageFactory
    ) {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
    }

    /**
     * Index action
     *
     * @return \Magento\Backend\Model\View\Result\Page
     */
    public function execute()
    {
        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        $resultPage = $this->resultPageFactory->create();
        $resultPage->setActiveMenu('Efloor_Review::post');
        $resultPage->addBreadcrumb(__('Customer Reviews'), __('Customer Review'));
        $resultPage->addBreadcrumb(__('Manage Customer Review'), __('Manage Customer Review'));
        $resultPage->getConfig()->getTitle()->prepend(__('Customer Reviews'));

        return $resultPage;
    }

    /**
     * Is the user allowed to view the review post grid.
     *
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Efloor_Review::post');
    }


}