<?php
namespace Efloor\Requestquote\Model;
class Gridproduct extends \Magento\Framework\Model\AbstractModel

{

/**

* Define resource model

*/

protected function _construct()

{

$this->_init('Efloor\Requestquote\Model\Resource\Gridproduct.php');

}

}



