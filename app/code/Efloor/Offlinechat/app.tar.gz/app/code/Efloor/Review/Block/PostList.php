<?php

/**
 * Class for getting the post list in adminhtml
 * 
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */


//Define the namespace
namespace Efloor\Review\Block;

use Efloor\Review\Api\Data\PostInterface;
use Efloor\Review\Model\ResourceModel\Post\Collection as PostCollection;

/**
 * Class which contain method to get the customer review listing
 */
class PostList extends \Magento\Framework\View\Element\Template implements
    \Magento\Framework\DataObject\IdentityInterface
{
    /**
     * @var \\Efloor\Review\Model\ResourceModel\Post\CollectionFactory
     */
    protected $_postCollectionFactory;

    /**
     * Construct
     *
     * @param \Magento\Framework\View\Element\Template\Context $context 
     * @param \Efloor\Review\Model\ResourceModel\Post\CollectionFactory $postCollectionFactory,
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Efloor\Review\Model\ResourceModel\Post\CollectionFactory $postCollectionFactory,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->_postCollectionFactory = $postCollectionFactory;
    }

    /**
     * Get all the review post
     * 
     * @return \Efloor\Review\Model\ResourceModel\Post\Collection
     */
    public function getPosts()
    {
        // Check if posts has already been defined
        // makes our block nice and re-usable! We could
        // pass the 'posts' data to this block, with a collection
        // that has been filtered differently!
        if (!$this->hasData('posts')) {
            $posts = $this->_postCollectionFactory
                ->create()
                ->addFilter('is_active', 1)
                ->addOrder(
                    PostInterface::CREATION_TIME,
                    PostCollection::SORT_ORDER_DESC
                );
            $this->setData('posts', $posts);
        }
        return $this->getData('posts');
    }

    /**
     * Return identifiers for produced content
     *
     * @return array
     */
    public function getIdentities()
    {
        return [\Efloor\Review\Model\Post::CACHE_TAG . '_' . 'list'];
    }
}
?>