<?php namespace Efloor\Requestquote\Model;

class Submitquote extends \Magento\Framework\Model\AbstractModel {

    public function _construct() {
        $this->_init('Efloor\Requestquote\Model\Resource\Submitquote');
    }

}
