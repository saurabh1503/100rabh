<?php

namespace Efloor\Common\Block\Product;

/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */


use Magento\Catalog\Model\Product;

class Description extends \Magento\Framework\View\Element\Template {

    /**
     * @var Product
     */
    protected $_product = null;

    /**
     * Core registry
     *
     * @var \Magento\Framework\Registry
     */
    protected $_coreRegistry = null;

    /**
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param array $data
     */
    public function __construct(
    \Magento\Framework\View\Element\Template\Context $context, \Magento\Framework\Registry $registry, array $data = []
    ) {
        $this->_coreRegistry = $registry;
        parent::__construct($context, $data);
    }

    /**
     * @return Product
     */
    public function getProduct() {

        if (!$this->_product) {
            $this->_product = $this->_coreRegistry->registry('product');
        }
        return $this->_product;
    }

    public function getInstallationLibraryData() {
        $libraryContent = $this->getInstallationData();
        return $this->getLibraryContent($libraryContent);  
    }
    
    
        public function getDescriptionLibraryData() {
        $libraryContent = $this->getDescriptionData();
        return $this->getLibraryContent($libraryContent);
    }
    
    
        public function getWarrantyLibraryData() {
        $libraryContent = $this->getWarrantyData();
        return $this->getLibraryContent($libraryContent);
    }
	public function getTrimsAccessoriesLibraryData() {
        $libraryContent = $this->getTrimsAccessoriesData();
		return $this->getLibraryContent($libraryContent);
      
    }

    public function getLibraryContent($libraryContent) {

        $libraryKey = false;

        if ($libraryContentKey = substr($libraryContent, 0, 20)) {
            if (strpos($libraryContentKey, 'library') !== false) {
                $libraryKey = true;
            } else {
                   return $libraryContent;
            }
        } else {

         
        }

        if ($libraryKey) {
            $libraryContentKey = strip_tags($libraryContentKey);
            $getInstallationLibrary = $this->checkLibraryContent($libraryContentKey);
        } else {
            $getInstallationLibrary = '';
        }

        return $getInstallationLibrary;
    }

    private function checkLibraryContent($libraryKey) {

        $objectManager = \Magento\Framework\App\ObjectManager::getInstance(); // Instance of object manager
        $resource = $objectManager->get('Magento\Framework\App\ResourceConnection');
        $connection = $resource->getConnection();
        $tableName = $resource->getTableName('efloor_libraryindex'); //gives table name with prefix

        $sql = $connection->select()
                ->from($tableName) // to select all fields            
                ->where('library_key = ?', $libraryKey);

        $results = $connection->fetchAll($sql);
        $result = $connection->query($sql);

        if ($result) {
            foreach ($results as $result) {
                if ($libraryContent = $result['library_content']) {
                    return $libraryContent;
                } else {
                    return $libraryKey;
                }
            }
        } else {
            return $libraryKey;
        }
    }

    private function getInstallationData() {

        $product = $this->getProduct();
        return $product->getData('installation');
    }

    private function getDescriptionData() {

        $product = $this->getProduct();
        return $product->getData('description');
    }

    private function getWarrantyData() {

        $product = $this->getProduct();
		return $product->getData('library_key');
       
    }
	private function getTrimsAccessoriesData() {

        $product = $this->getProduct();
		return $product->getData('Trims_accessories');
       
    }
		
		
	public function getWarrantyContent() {
		$content = "";
        $product = $this->getProduct();
        $library_key = $product->getData('library_key');
		if(!empty($library_key)) {
			$content = $this->getLibraryHtmlContent($library_key);
			return $content;
		}
		elseif(!empty($product->getData('warranty_key_pdf'))){
			$library_key = $product->getData('warranty_key_pdf');
			$content = '<a style="font-size: 24px;color: #333; margin-left: 55px;" href="/'.$library_key.'" target="_blank">Click here to view the warranty information</a><p></p><p style="text-align: center;">In order to view the specification information for this product,<br>you must have a PDF reader installed, such as "Adobe Acrobat Reader".</p><p></p><p style="text-align: center;"><a href="https://www.adobe.com/products/acrobat/readstep2.html"><img src="https://www.adobe.com/images/get_adobe_reader.gif" alt="Get Adobe Reader"></a></p>';
		
       
			return $content;
		}
		elseif(!empty($product->getData('warranty'))){
			 $content = $product->getData('warranty');
			 return $content;
		}
		
		return false;
	
	}
	
	public function getInstallationContent() {
		$content = "";
        $product = $this->getProduct();
        $library_key = $product->getData('installation_key');
		if(!empty($library_key)) {
			$content = $this->getLibraryHtmlContent($library_key);
			
			return $content;
		}
		elseif(!empty($product->getData('installation_key_pdf'))){
			$library_key = $product->getData('installation_key_pdf');
			$content = '<a style="font-size: 24px;color: #333; margin-left: 55px;" href="/'.$library_key.'" target="_blank">Click here to view the Installation information</a><p></p><p style="text-align: center;">In order to view the specification information for this product,<br>you must have a PDF reader installed, such as "Adobe Acrobat Reader".</p><p></p><p style="text-align: center;"><a href="https://www.adobe.com/products/acrobat/readstep2.html"><img src="https://www.adobe.com/images/get_adobe_reader.gif" alt="Get Adobe Reader"></a></p>';
			
			return $content;
		}
		elseif(!empty($product->getData('installation'))){
			 $content = $product->getData('installation');
			 return $content;
		}
		
		return false;
       
	   
    }
	
	public function getFeaturesContent() {
		$content = "";
        $product = $this->getProduct();
        $library_key = $product->getData('features_key');
		if(!empty($library_key)) {
			$content = $this->getLibraryHtmlContent($library_key);
			
			return $content;
		}
		elseif(!empty($product->getData('features_pdf'))){
			$library_key = $product->getData('features_pdf');
			$content = '<a style="font-size: 24px;color: #333; margin-left: 55px;" href="/'.$library_key.'" target="_blank">Click here to view the Features & Benfits information</a><p></p><p style="text-align: center;">In order to view the specification information for this product,<br>you must have a PDF reader installed, such as "Adobe Acrobat Reader".</p><p></p><p style="text-align: center;"><a href="https://www.adobe.com/products/acrobat/readstep2.html"><img src="https://www.adobe.com/images/get_adobe_reader.gif" alt="Get Adobe Reader"></a></p>';
			
			return $content;
		}
		elseif(!empty($product->getData('features_benefits'))){
			 $content = $product->getData('features_benefits');
			 return $content;
		}	
		
	   return false;
	   
    }
	
	
		public function getAvalibilityContent() {
		$content = "";
        $product = $this->getProduct();
        $library_key = $product->getData('pavailbility');
		
		if(!empty($library_key)) {
			if (strpos($library_key, 'library') !== false) {
			$content = $this->getLibraryHtmlContent($library_key);
			
			return $content;
		 }
		 else{
			 $content = $product->getData('features_benefits');
			 return $content;
		}	
		}
		
	   return false;
	   
    }

	private function getLibraryHtmlContent($libraryKey){
		
		
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance(); // Instance of object manager
        $resource = $objectManager->get('Magento\Framework\App\ResourceConnection');
        $connection = $resource->getConnection();
        $tableName = $resource->getTableName('efloor_libraryindex'); //gives table name with prefix

        $sql = $connection->select()
                ->from($tableName) // to select all fields            
                ->where('library_key = ?', $libraryKey);
		
        $results = $connection->fetchAll($sql);
		$ibrary_content = '';
		foreach($results as $result) {
			$ibrary_content = $result['library_content'];
		}
		
		return $ibrary_content;
	}	

		
		
}
