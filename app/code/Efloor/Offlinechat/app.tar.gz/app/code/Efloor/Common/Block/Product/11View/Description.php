<?php

namespace Efloor\Common\Block\Product\View;

/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

/**
 * Product description block
 *
 * @author     Magento Core Team <core@magentocommerce.com>
 */
use Magento\Catalog\Model\Product;

class Description extends \Magento\Catalog\Block\Product\View\Description {

    /**
     * @var Product
     */
    protected $_product = null;

    /**
     * Core registry
     *
     * @var \Magento\Framework\Registry
     */
    protected $_coreRegistry = null;

    /**
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param array $data
     */
    public function __construct(
    \Magento\Framework\View\Element\Template\Context $context, \Magento\Framework\Registry $registry, array $data = []
    ) {
        $this->_coreRegistry = $registry;
        parent::__construct($context, $data);
    }

    /**
     * @return Product
     */
    public function getProduct() {

        if (!$this->_product) {
            $this->_product = $this->_coreRegistry->registry('product');
        }
        return $this->_product;
    }

    	public function checkCalculator() {        
       $psfpercarton =  $this->checkPsfPerCarton();

       $pshowprice = $this->checkPshowPrice();	   

	   if($psfpercarton && $pshowprice) {	   
			 return true;
	   } else  {
			return false;
	   }     
    }
	
	
	public function checkPsfPerCarton() {	
	    $psfpercarton = $this->getProduct()->getData('sold_by');
			if($psfpercarton) {		
				return true;		
			} else {
				return false;		
			}	
	}
	
	public function checkCustomer() {
	
	$checkuser = $this->checkUsergroup();
	$psfpercarton =  $this->checkPsfPerCarton();
	if($checkuser && $psfpercarton) {
	
	return true;
	
	} else {
	
	return false;
	
	}
	
	}
	
	public function customerNotInGroup() {
	
	$psfpercarton =  $this->checkPsfPerCarton();
	$pshowprice = $this->checkPshowPrice();	
	
	if($psfpercarton && empty($pshowprice)) {
	
	return true;
	} else {
	
	return false;
	}
	
	
	}
	
	public function checkPshowPrice() {	
		$pshowprice =  $this->getProduct()->getData('pshowprice');

		if($pshowprice == 0 || $pshowprice == 1) {		
		   return true;		
		} else {
		   return false;
		
		}
	}
	
	public function checkUsergroup() {	
		return false;
	
	}

}
