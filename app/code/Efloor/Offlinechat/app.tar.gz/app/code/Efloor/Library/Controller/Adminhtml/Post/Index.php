<?php
namespace Efloor\Library\Controller\Adminhtml\Post;

use Magento\Backend\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;

class Index extends \Magento\Backend\App\Action
{

    /**
     * @var PageFactory
     */
    protected $resultPageFactory;

    /**
     * @param Context $context
     * @param PageFactory $resultPageFactory
     */
    public function __construct(
        Context $context,
        PageFactory $resultPageFactory
    ) {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
    }

    /**
     * Index action
     *
     * @return \Magento\Backend\Model\View\Result\Page
     */
    public function execute()
    {
        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        $resultPage = $this->resultPageFactory->create();
        $resultPage->setActiveMenu('Efloor_Library::post');
        $resultPage->addBreadcrumb(__('Customer Library'), __('Customer Library'));
        $resultPage->addBreadcrumb(__('Manage Customer Library'), __('Manage Customer Library'));
        $resultPage->getConfig()->getTitle()->prepend(__('Customer Library'));

        return $resultPage;
    }

    /**
     * Is the user allowed to view the Library post grid.
     *
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Efloor_Library::post');
    }


}