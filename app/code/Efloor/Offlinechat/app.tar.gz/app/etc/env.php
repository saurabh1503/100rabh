<?php
return array (
  'backend' => 
  array (
    'frontName' => 'admin',
  ),
  'crypt' => 
  array (
    'key' => 'e5e1d04a5360231a3923ed70e8ef9182',
  ),
  'session' => 
  array (
    'save' => 'memcached',
    'save_path' => '127.0.0.1:11211',
  ),
  'db' => 
  array (
    'table_prefix' => '',
    'connection' => 
    array (
      'default' => 
      array (
        'host' => 'localhost',
        'dbname' => 'qaefloor_efloors',
        'username' => 'qaefloor_admin',
        'password' => 'iIV#rWRUm?[Q',
        'active' => '1',
        'model' => 'mysql4',
        'engine' => 'innodb',
        'initStatements' => 'SET NAMES utf8;',
      ),
    ),
  ),
  'resource' => 
  array (
    'default_setup' => 
    array (
      'connection' => 'default',
    ),
  ),
  'x-frame-options' => 'SAMEORIGIN',
  'MAGE_MODE' => 'production',
  'cache_types' => 
  array (
    'config' => 1,
    'layout' => 1,
    'block_html' => 1,
    'collections' => 1,
    'reflection' => 1,
    'db_ddl' => 1,
    'eav' => 1,
    'customer_notification' => 1,
    'full_page' => 1,
    'config_integration' => 1,
    'config_integration_api' => 1,
    'translate' => 1,
    'config_webservice' => 1,
    'compiled_config' => 0,
  ),
  'install' => 
  array (
    'date' => 'Fri, 09 Dec 2016 10:30:50 +0000',
  ),
  'http_cache_hosts' => 
  array (
    0 => 
    array (
      'host' => '127.0.0.1',
      'port' => '6081',
    ),
  ),
);
