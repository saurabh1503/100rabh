require([
    'jquery',
    'jquery/ui',
    'customSelect'
],function(){
/* var data = jQuery(".rd-navbar-nav-wrap ul li:last").html();


var htmldata = '<li class="level0 nav-7  level-top">'+data+'</li>';

jQuery(".rd-navbar-nav-wrap ul li:first").after(htmldata);
 */

jQuery( document ).ajaxComplete(function() {
   var len = window.location.search;
     length1 = len.length;
     if(length1 != ''){
          jQuery('.right-side-wrap').hide();
     }else{
     jQuery('.right-side-wrap').show();
    }
});
jQuery(window).load(function(){  
var len = window.location.search;
     length1 = len.length;
     if(length1 != ''){
          jQuery('.right-side-wrap').hide();
     }else{
     jQuery('.right-side-wrap').show();
    }
	
})

});