define([
    'jquery',
    'jquery/ui',
    'customSelect'
], function ($, select2) {
    'use strict';

    $.widget('TemplateMonster.selectize', {

        options: {
           allowClear: false,
        },

        _create: function() {

            var selector = this.element;
            var params = this.options;

            $(selector).select2(params);

            // $(document).ajaxComplete(function(){
            //     selector.select2("destroy");
            //     selector.select2(params);
            // });

            $('.swatch-option').on('click', function(){
                selector.select2("destroy");
                selector.select2(params);
            });
        },
    });

    return $.TemplateMonster.selectize;

});