define([
    'jquery',
    'theme',
    'selectize',
    'doubletaptogo'
], function ($, selectize, doubletaptogo) {
    'use strict';

    $.widget('TemplateMonster.themeChild', $.TemplateMonster.theme, {

        options: {
            crosssellCarousel: {
                selector: ".block.crosssell .product-items",
                params: {
                    items: 4
                }
            },
            relatedCarousel: {
                params: {
                    loop: true,
                    items: 2,
                    autoPlay: true,
                    itemsDesktop: [1199,2],
                    itemsDesktopSmall: [979,2],
                    itemsTablet: [768,2],
                    itemsMobile: [400,1]
                }
            },
            upsellCarousel: {
                params: {
                    loop: true,
                    items: 2
                }
            },
            easydropdown: {
                selector: ".product-options-wrapper select, #limiter, #shipping-new-address-form select",
            }
        },
		
		_crossellCarousel: function () {
            /* Crossell init */
            var data = this.options.crosssellCarousel;
            $(data.selector).carouselInit(data.params);
        },

		_easydropdown: function() {
            var data = this.options.easydropdown;
            $(data.selector).selectize();

        },

        _productsCarousel: function () {
            /* Related init */
            var relatedCarouselData = this.options.relatedCarousel;
            var related = $(relatedCarouselData.selector).carouselInit(relatedCarouselData.params);

            /* Upsell init */
            var upsellCarouselData = this.options.upsellCarousel;
            var items = 3,
                upsellLimit = $('.block.upsell').data('limit'),
                itemsCount = 1;
            if (upsellLimit != 0) {
                $('.block.upsell .product-item').each(function(){
                    if (itemsCount > upsellLimit){
                        $(this).remove();
                    }
                    itemsCount++;
            });
            }
            var upsellParams = $.extend(true, {}, upsellCarouselData.params, {items: items});
            var upsell = $(upsellCarouselData.selector).carouselInit(upsellParams);

            if ($(relatedCarouselData.selector).length) {
                var startRelated = related.data('owlCarousel');
                startRelated.jumpTo(1);
            }
            if ($(upsellCarouselData.selector).length) {
                var startUpsell = upsell.data('owlCarousel');
                startUpsell.jumpTo(1);
            }
        },
        _homePageCarousel: function () {
            /* Crossell init */
            var data = this.options.crosssellCarousel;
            $('.man-carousel').carouselInit({
                items : 6,
                itemsDesktop : [1199,4],
                itemsDesktopSmall : [980,3],
                itemsTablet: [768,2],
                itemsTabletSmall: false,
                itemsMobile : [479,1]
            });
        },
		_bannerLayers: function(){
            var bannerHeading = $('.banner-4').find('.style-1');
            var headingLine = bannerHeading.find('span');

            headingLine.each(function(){
                var text = $(this).text();
                $(this).append('<span class="layer-0">' + text + '</span>');
                $(this).append('<span class="layer-1">' + text + '</span>');
            });
        },
        _dbTap: function(){
            $( '.rd-navbar-nav li:has(ul)' ).doubleTapToGo();
        },
        _create: function() {
            this._super();
            this._easydropdown();
			this._crossellCarousel();
            this._bannerLayers();
            this._homePageCarousel();
			this._dbTap();
            $(window).load(function(){
                $('body').on('click', function(){
                    $('.select', '#product-options-wrapper').selectize();
                    $('#limiter').selectize();
                });

            });
            $('#tab-label-reviews').on('click', function(){
                $('#limiter').selectize();
            });

        }
    });

    return $.TemplateMonster.themeChild;

});