/**
 * Copyright © 2015. All rights reserved.
 */

define([
    'jquery',
    'carousel',
    'owlcarousel'
], function($){
    "use strict";

    $.widget('TemplateMonster.carouselChild', $.TemplateMonster.carousel, {


        _create: function() {
            this._super();
            this.element.parents('.block-content').removeClass('ov-h');
        },
        
    });

    return $.TemplateMonster.carouselChild;

});
