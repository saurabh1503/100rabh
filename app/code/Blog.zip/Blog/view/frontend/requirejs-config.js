var config = {
    paths: {
        migrate: 'Mageplaza_Blog/js/lib/jquery-migrate-1.2.1.min',
        fancybox: 'Mageplaza_Blog/js/lib/jquery.fancybox-1.3.4.pack.min',
        comment: 'Mageplaza_Blog/js/comment',
        autocomplete: 'Mageplaza_Blog/js/lib/jquery.autocomplete.min'
    },
    shim:{
        fancybox: ['jquery']
    }
};